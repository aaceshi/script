RulePath="/usr/local/nginx/conf/waf/wafconf/"
attacklog="on"
logdir="/home/logs/"
UrlDeny="on"
Redirect="on"
CookieMatch="on"
postMatch="on" 
whiteModule="on" 
black_fileExt={"php"}
ipWhitelist={"127.0.0.1"}
ipBlocklist={""}
CCDeny="on"
--cc rate the xxx of xxx seconds
CCrate="150/60"
html=[[
<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=0.5, maximum-scale=1.3, user-scalable=yes"/><title>ILLegal Request - Website Firewall</title><style type="text/css">body{width:100%;height:100%;background:#c3c3c3;padding:0;margin:0 auto;font-family:Microsoft Yahei,sans-serif}@media screen and (max-width:800px){.kvmgocom{position:absolute;display:block;margin:0 auto;left:15%;top:8%}}@media screen and (min-width:800px){.kvmgocom{position:absolute;display:block;margin:0 auto;left:25%;top:8%}}</style></head><body><div class="kvmgocom"><div style="max-width:77%;max-height:100%; float:left;"><div style="height:40px; line-height:40px; color:#fff; font-size:20px; overflow:hidden; background:#c00; padding-left:20px;">Website Firewall</div><div style="border:1px dashed #cdcece; border-top:none; font-size:16px; background:#fff; color:#555; line-height:24px; height:100%; padding:20px 20px 0 20px; overflow-y:auto;background:#f3f7f9;"><p style="margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style="font-weight:600; color:#fc4f03;">Sorry , Your visit has been Blocked ! </span></p><p style="margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;">Probable Cause, Your Request Contains Attack ! </p><p style="margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:1; text-indent:0px;">How to solve:</p><ul style="margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-list-indent: 1;"><li style="margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;">1）Check Submitted Content；</li><li style="margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;">2）General site visitors, please leave a message to the site administrator and later access；</li><br/></ul></div></div></div></body></html>
]]
